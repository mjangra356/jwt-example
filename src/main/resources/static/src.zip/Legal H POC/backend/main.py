from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from services.ai_service import extract_relationships
from services.comparison_service import compare_results
import uvicorn
import shutil
import os
import json
import uuid
from typing import Optional

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
RESULTS_DIR = "results"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

@app.post("/extract")
async def extract_entity_relationships(file: UploadFile = File(...)):
    try:
        # Save temp file
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        # Extract data using AI Service
        try:
            with open(file_path, "rb") as image_file:
                image_bytes = image_file.read()
                result = await extract_relationships(image_bytes)
                
            # Save extracted result to file
            result_filename = f"extracted_{uuid.uuid4()}.json"
            result_path = os.path.join(RESULTS_DIR, result_filename)
            with open(result_path, "w") as f:
                json.dump(result, f, indent=2)
                
        finally:
            # Cleanup
            if os.path.exists(file_path):
                os.remove(file_path)
                
        return result
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/compare")
async def compare_extracted_with_source(
    extracted_data: str = Form(...),
    source_file: UploadFile = File(...)
):
    try:
        extracted_json = json.loads(extracted_data)
        source_content = await source_file.read()
        source_json = json.loads(source_content)
        
        comparison = compare_results(extracted_json, source_json)
        return comparison
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
