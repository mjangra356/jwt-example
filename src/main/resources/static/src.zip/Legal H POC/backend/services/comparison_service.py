
def compare_results(extracted_json: dict, source_json: dict) -> dict:
    """
    Compares the extracted JSON with the source JSON.
    Returns a dictionary containing differences.
    """
    comparison = {
        "entities": {
            "missing": [],  # In source, not in extracted
            "extra": [],    # In extracted, not in source
            "matched": []   # In both
        },
        "relationships": {
            "missing": [],
            "extra": [],
            "mismatched_ownership": [],
            "matched": []
        }
    }

    # compare entities
    source_entities = {e.get('name'): e for e in source_json.get('entities', [])}
    extracted_entities = {e.get('name'): e for e in extracted_json.get('entities', [])}

    for name, entity in source_entities.items():
        if name not in extracted_entities:
            comparison["entities"]["missing"].append(entity)
        else:
             comparison["entities"]["matched"].append(entity)

    for name, entity in extracted_entities.items():
        if name not in source_entities:
            comparison["entities"]["extra"].append(entity)

    # compare relationships
    # Key usage: (from, to)
    source_rels = {}
    for r in source_json.get('relationships', []):
        key = (r.get('from'), r.get('to'))
        source_rels[key] = r

    extracted_rels = {}
    for r in extracted_json.get('relationships', []):
        key = (r.get('from'), r.get('to'))
        extracted_rels[key] = r

    for key, rel in source_rels.items():
        if key not in extracted_rels:
            comparison["relationships"]["missing"].append(rel)
        else:
            # Check ownership mismatch
            ext_rel = extracted_rels[key]
            if rel.get('ownership') != ext_rel.get('ownership'):
                 comparison["relationships"]["mismatched_ownership"].append({
                     "from": key[0],
                     "to": key[1],
                     "source_ownership": rel.get('ownership'),
                     "extracted_ownership": ext_rel.get('ownership')
                 })
            else:
                comparison["relationships"]["matched"].append(rel)

    for key, rel in extracted_rels.items():
        if key not in source_rels:
            comparison["relationships"]["extra"].append(rel)

    return comparison
