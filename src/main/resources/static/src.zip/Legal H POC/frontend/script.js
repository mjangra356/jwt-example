const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const previewArea = document.getElementById('preview-area');
const imagePreview = document.getElementById('image-preview');
const removeBtn = document.getElementById('remove-btn');
const extractBtn = document.getElementById('extract-btn');
const btnSpinner = document.getElementById('btn-spinner');
const resultsSection = document.getElementById('results-section');
const jsonOutput = document.getElementById('json-output');
const visualOutput = document.getElementById('visual-output');
const sourceInput = document.getElementById('source-input');
const sourceFileName = document.getElementById('source-file-name');
const comparisonOutput = document.getElementById('comparison-output');
const compBtn = document.getElementById('comp-btn');
const saveLocation = document.getElementById('save-location');
let cy = null;

const compareActionsBtn = document.getElementById('compare-actions-btn');

let currentFile = null;
let currentSourceFile = null;
let lastExtractedData = null;

// Drag and Drop
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length > 0) handleFile(files[0]);
});

dropZone.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) handleFile(e.target.files[0]);
});

// Source JSON Handler
sourceInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        currentSourceFile = e.target.files[0];
        sourceFileName.textContent = `Source JSON: ${currentSourceFile.name}`;
        if (lastExtractedData) compareActionsBtn.disabled = false;
    }
});

function handleFile(file) {
    if (!file.type.startsWith('image/')) {
        alert('Please upload an image file.');
        return;
    }
    currentFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
        imagePreview.src = e.target.result;
        dropZone.hidden = true;
        previewArea.hidden = false;
        extractBtn.disabled = false;
        resultsSection.hidden = true;
        compareActionsBtn.disabled = true;
        lastExtractedData = null;
    };
    reader.readAsDataURL(file);
}

removeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    currentFile = null;
    imagePreview.src = '';
    fileInput.value = '';

    // Reset source
    currentSourceFile = null;
    sourceInput.value = '';
    sourceFileName.textContent = '';
    compareActionsBtn.disabled = true;
    lastExtractedData = null;

    dropZone.hidden = false;
    previewArea.hidden = true;
    extractBtn.disabled = true;
    resultsSection.hidden = true;
    if (cy) {
        cy.destroy();
        cy = null;
    }
});

// Extraction
extractBtn.addEventListener('click', async () => {
    if (!currentFile) return;

    setLoading(true);
    resultsSection.hidden = true;
    compBtn.hidden = true; // hide prev diff

    try {
        const formData = new FormData();
        formData.append('file', currentFile);

        const response = await fetch('http://localhost:8000/extract', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Extraction failed');
        }

        const data = await response.json();
        lastExtractedData = data;
        displayResults(data);
        initGraph(data);

        // Enable compare if source exists
        if (currentSourceFile) {
            compareActionsBtn.disabled = false;
        }

    } catch (error) {
        alert(error.message);
        console.error(error);
    } finally {
        setLoading(false);
    }
});

// Comparison
compareActionsBtn.addEventListener('click', async () => {
    if (!lastExtractedData || !currentSourceFile) return;

    compareActionsBtn.disabled = true;
    compareActionsBtn.querySelector('span').textContent = 'Comparing...';

    try {
        const formData = new FormData();
        formData.append('extracted_data', JSON.stringify(lastExtractedData));
        formData.append('source_file', currentSourceFile);

        const response = await fetch('http://localhost:8000/compare', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Comparison failed');
        }

        const comparison = await response.json();
        compBtn.hidden = false;
        renderComparison(comparison);

        // Switch to comparison tab
        compBtn.click();

    } catch (error) {
        alert(error.message);
        console.error(error);
    } finally {
        compareActionsBtn.disabled = false;
        compareActionsBtn.querySelector('span').textContent = 'Compare with Source';
    }
});


function setLoading(isLoading) {
    extractBtn.disabled = isLoading;
    btnSpinner.hidden = !isLoading;
    extractBtn.querySelector('span').textContent = isLoading ? 'Extracting...' : 'Extract Relationships';
}

function displayResults(data) {
    resultsSection.hidden = false;

    // JSON View
    jsonOutput.textContent = JSON.stringify(data, null, 2);
    hljs.highlightElement(jsonOutput);

    // Visual View
    visualOutput.innerHTML = '';

    if (data.relationships && Array.isArray(data.relationships)) {
        data.relationships.forEach(rel => {
            const card = document.createElement('div');
            card.className = 'rel-card';
            card.innerHTML = `
                <div class="entity">${rel.from}</div>
                <div class="arrow">
                    <span class="ownership">${rel.ownership || rel.type || '?'}</span>
                </div>
                <div class="entity">${rel.to}</div>
            `;
            visualOutput.appendChild(card);
        });
    } else {
        visualOutput.innerHTML = '<p style="color:var(--text-secondary);text-align:center;">No relationship data found to visualize.</p>';
    }

    // Comparison View
    // Clean up previous result
    compBtn.hidden = true;
    comparisonOutput.innerHTML = '';
}

function renderComparison(comp) {
    let html = '';

    // Missing Entities (Red)
    comp.entities.missing.forEach(e => {
        html += `<div class="rel-card" style="border-left: 4px solid #ef4444;">
            <div class="entity" style="background: rgba(239, 68, 68, 0.2); color: #fca5a5;">Missing Entity: ${e.name}</div>
        </div>`;
    });

    // Extra Entities (Yellow)
    comp.entities.extra.forEach(e => {
        html += `<div class="rel-card" style="border-left: 4px solid #eab308;">
            <div class="entity" style="background: rgba(234, 179, 8, 0.2); color: #fde047;">Extra Entity: ${e.name}</div>
        </div>`;
    });

    // Missing Relationships (Red)
    comp.relationships.missing.forEach(r => {
        html += `<div class="rel-card" style="border-left: 4px solid #ef4444;">
             <span style="color:#ef4444; font-weight:bold; margin-right:10px;">Missing:</span>
             <div class="entity">${r.from}</div>
             <div class="arrow"><span class="ownership">${r.ownership || '?'}</span></div>
             <div class="entity">${r.to}</div>
        </div>`;
    });

    // Extra Relationships (Yellow)
    comp.relationships.extra.forEach(r => {
        html += `<div class="rel-card" style="border-left: 4px solid #eab308;">
             <span style="color:#eab308; font-weight:bold; margin-right:10px;">Extra:</span>
             <div class="entity">${r.from}</div>
             <div class="arrow"><span class="ownership">${r.ownership || '?'}</span></div>
             <div class="entity">${r.to}</div>
        </div>`;
    });

    // Mismatches (Orange)
    comp.relationships.mismatched_ownership.forEach(m => {
        html += `<div class="rel-card" style="border-left: 4px solid #f97316;">
             <span style="color:#f97316; font-weight:bold; margin-right:10px;">Mismatch:</span>
             <div class="entity">${m.from}</div>
             <div class="arrow">
                <span class="ownership" style="text-decoration:line-through; margin-right:5px;">${m.source_ownership}</span>
                <span class="ownership" style="border-color:#f97316;">${m.extracted_ownership}</span>
             </div>
             <div class="entity">${m.to}</div>
        </div>`;
    });

    if (html === '') {
        html = '<div class="rel-card" style="border-left: 4px solid #10b981;"><p style="width:100%; text-align:center; color:#10b981;">Perfect Match!</p></div>';
    }

    comparisonOutput.innerHTML = html;
}

function initGraph(data) {
    const elements = [];
    const addedNodes = new Set();

    // Helper to add node
    const addNode = (name) => {
        if (!name || addedNodes.has(name)) return;
        elements.push({
            data: { id: name, label: name }
        });
        addedNodes.add(name);
    };

    // Process Entities if exists
    if (data.entities) {
        data.entities.forEach(e => addNode(e.name));
    }

    // Process Relationships
    if (data.relationships) {
        data.relationships.forEach((rel, index) => {
            addNode(rel.from);
            addNode(rel.to);

            elements.push({
                data: {
                    id: `e${index}`,
                    source: rel.from,
                    target: rel.to,
                    label: rel.ownership || ''
                }
            });
        });
    }

    // Initialize Cytoscape
    cy = cytoscape({
        container: document.getElementById('cy'),
        elements: elements,
        style: [
            {
                selector: 'node',
                style: {
                    'background-color': '#4f46e5', // Indigo-600
                    'label': 'data(label)',
                    'color': '#ffffff',
                    'font-size': '12px',
                    'font-weight': 'bold',
                    'text-valign': 'center',
                    'text-halign': 'center',
                    'width': 'label',
                    'height': 'label',
                    'padding': '12px',
                    'shape': 'round-rectangle',
                    'text-outline-width': 2,
                    'text-outline-color': '#4f46e5',
                    'border-width': 2,
                    'border-color': '#818cf8', // Indigo-400
                    'overlay-opacity': 0
                }
            },
            {
                selector: 'edge',
                style: {
                    'width': 2,
                    'line-color': '#94a3b8',
                    'target-arrow-color': '#94a3b8',
                    'target-arrow-shape': 'triangle',
                    'curve-style': 'bezier', // Curved lines
                    'control-point-step-size': 40,
                    'label': 'data(label)',
                    'color': '#cbd5e1',
                    'font-size': '10px',
                    'text-background-color': '#1e293b',
                    'text-background-opacity': 0.8,
                    'text-background-padding': '4px',
                    'text-background-shape': 'round-rectangle',
                    'text-rotation': 'autorotate', // Rotate text with edge
                    'arrow-scale': 1.2
                }
            },
            {
                selector: ':selected',
                style: {
                    'background-color': '#ec4899', // Pink-500
                    'line-color': '#ec4899',
                    'target-arrow-color': '#ec4899',
                    'source-arrow-color': '#ec4899',
                    'text-outline-color': '#ec4899'
                }
            }
        ],
        layout: {
            name: 'breadthfirst',
            directed: true,
            padding: 50,
            spacingFactor: 1.5,
            animate: true,
            animationDuration: 500,
            avoidOverlap: true
        }
    });
}

// Tabs
const toggleBtns = document.querySelectorAll('.toggle-btn');
toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        toggleBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const view = btn.dataset.view;
        document.getElementById('json-view').hidden = view !== 'json';
        document.getElementById('visual-view').hidden = view !== 'visual';

        const compView = document.getElementById('comparison-view');
        if (compView) compView.hidden = view !== 'comparison';

        const graphView = document.getElementById('graph-view');
        if (graphView) {
            graphView.hidden = view !== 'graph';
            // Resize graph when becoming visible
            if (view === 'graph' && cy) {
                setTimeout(() => {
                    cy.resize();
                    cy.layout({ name: 'cose' }).run();
                }, 50);
            }
        }
    });
});
