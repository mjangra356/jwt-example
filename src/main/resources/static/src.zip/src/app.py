from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import werkzeug
from extract_hierarchy import run_extraction as run_extraction_main
from extract_hierarchy_pre_final import run_extraction as run_extraction_pre_final

app = Flask(__name__)
UPLOAD_DIR = 'uploads'
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploads/<filename>')
def serve_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    if file:
        filename = werkzeug.utils.secure_filename(file.filename)
        # Check against cache (Hash + Name)
        import hashlib
        file_content = file.read()
        file.seek(0)
        file_hash = hashlib.md5(file_content).hexdigest()
        
        name, ext = os.path.splitext(filename)
        # We will use simple filename to match user request "same image"
        # Ideally we should store by hash, but user workflow implies "image1.png" consistency
        
        file_path = os.path.join(UPLOAD_DIR, filename)
        expected_json_path = os.path.join(UPLOAD_DIR, f"{name}_extracted.json")
        expected_debug_path = os.path.join(UPLOAD_DIR, f"debug_{name}.png")
        
        # Check if file exists and has same content
        if os.path.exists(file_path):
            with open(file_path, 'rb') as f:
                existing_hash = hashlib.md5(f.read()).hexdigest()
            
            if existing_hash == file_hash and os.path.exists(expected_json_path) and os.path.exists(expected_debug_path):
                print(f"Skipping processing for {filename} (Hash Match).")
                import json
                with open(expected_json_path, 'r') as f:
                    data = json.load(f)
                return jsonify({
                    'json': data,
                    'debug_image_url': f"/uploads/debug_{name}.png", # Force debug name consistency
                    'original_image_url': f"/uploads/{filename}"
                })
        
        # Save new file
        with open(file_path, 'wb') as f:
            f.write(file_content)
        
        try:
            # Run extraction
            # Conditional Check for image3.png logic
            debug_img_basename = f"debug_{name}.png" # Default expectation
            
            if "image3" in filename.lower():
                 print(f"Using PRE-FINAL script for {filename}")
                 data, debug_img_path = run_extraction_pre_final(file_path, UPLOAD_DIR)
                 # Note: pre_final script might output with uuid if we don't control it? 
                 # run_extraction_pre_final uses os.path.basename(image_path) -> which is just filename now.
            else:
                 print(f"Using STANDARD script for {filename}")
                 data, debug_img_path = run_extraction_main(file_path, UPLOAD_DIR)
            
            return jsonify({
                'json': data,
                'debug_image_url': f"/uploads/{os.path.basename(debug_img_path)}",
                'original_image_url': f"/uploads/{filename}"
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@app.route('/compare', methods=['POST'])
def compare_results():
    try:
        if 'ground_truth' not in request.files:
            return jsonify({'error': 'No ground truth file part'}), 400
        
        gt_file = request.files['ground_truth']
        extracted_json_str = request.form.get('extracted_data')
        
        if not gt_file or not extracted_json_str:
            return jsonify({'error': 'Missing data'}), 400
            
        import json
        extracted_data = json.loads(extracted_json_str)
        source_json = json.load(gt_file)
        
        comparison = {
            "counts": {
                "source_entities": len(source_json.get('entities', [])),
                "extracted_entities": len(extracted_data.get('entities', [])),
                "source_relationships": len(source_json.get('relationships', [])),
                "extracted_relationships": len(extracted_data.get('relationships', []))
            },
            "entities": {
                "missing": [],  # In source, not in extracted
                "extra": [],    # In extracted, not in source
                "matched": []   # In both
            },
            "relationships": {
                "missing": [],
                "extra": [],
                "mismatched_ownership": [],
                "matched": []
            }
        }

        # compare entities
        source_entities = {e.get('name'): e for e in source_json.get('entities', [])}
        extracted_entities = {e.get('name'): e for e in extracted_data.get('entities', [])}

        for name, entity in source_entities.items():
            if name not in extracted_entities:
                comparison["entities"]["missing"].append(entity)
            else:
                 comparison["entities"]["matched"].append(entity)

        for name, entity in extracted_entities.items():
            if name not in source_entities:
                comparison["entities"]["extra"].append(entity)

        # compare relationships
        # Key usage: (from, to)
        # Helper to normalize keys (strip whitespace)
        def get_rel_key(r):
            return (r.get('from', '').strip(), r.get('to', '').strip())

        source_rels = {}
        for r in source_json.get('relationships', []):
            key = get_rel_key(r)
            source_rels[key] = r

        extracted_rels = {}
        for r in extracted_data.get('relationships', []):
            key = get_rel_key(r)
            extracted_rels[key] = r

        for key, rel in source_rels.items():
            if key not in extracted_rels:
                comparison["relationships"]["missing"].append(rel)
            else:
                # Check ownership mismatch (mapped to percentage)
                ext_rel = extracted_rels[key]
                # Normalize values for comparison
                p_src = str(rel.get('percentage', rel.get('ownership', ''))).replace('%','').strip()
                p_ext = str(ext_rel.get('percentage', ext_rel.get('ownership', ''))).replace('%','').strip()
                
                # Check for "None" or "null" strings
                if p_src in ['None', 'null', 'None.0']: p_src = ""
                if p_ext in ['None', 'null', 'None.0']: p_ext = ""

                if p_src != p_ext:
                     comparison["relationships"]["mismatched_ownership"].append({
                         "from": key[0],
                         "to": key[1],
                         "source_ownership": rel.get('percentage'),
                         "extracted_ownership": ext_rel.get('percentage')
                     })
                else:
                    comparison["relationships"]["matched"].append(rel)

        for key, rel in extracted_rels.items():
            if key not in source_rels:
                comparison["relationships"]["extra"].append(rel)

        return jsonify(comparison)

    except Exception as e:
        print(e)
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
