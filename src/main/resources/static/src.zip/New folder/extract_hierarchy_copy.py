
import cv2
import pytesseract
import json
import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
import re
import os

# Configure tesseract path if necessary (Windows usually needs this)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

@dataclass
class Entity:
    id: int
    text: str
    rect: Tuple[int, int, int, int]  # x, y, w, h
    center: Tuple[int, int]
    type: str = "entity" # 'entity' or 'label'

def is_contained(inner_rect, outer_rect):
    ix, iy, iw, ih = inner_rect
    ox, oy, ow, oh = outer_rect
    return (ix >= ox) and (iy >= oy) and (ix + iw <= ox + ow) and (iy + ih <= oy + oh)

def preprocess_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Could not read image: {image_path}")
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # standard thresholding might work better if it's a clean chart
    # thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
    #                                cv2.THRESH_BINARY_INV, 11, 2)
    # Using Canny edge detection + Dilation often works better for solid boxes
    edges = cv2.Canny(gray, 50, 150)
    # Increase kernel width to merge horizontally spaced letters (wide kerning)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (8, 3))
    # Dilate to close gaps in edges - use 2 iterations to really smear text together
    thresh = cv2.dilate(edges, kernel, iterations=2)
    
    return img, gray, thresh

def find_text_boxes(thresh_img, original_img):
    # Find contours
    # Use RETR_TREE to find nested contours (boxes inside the frame)
    contours, hierarchy = cv2.findContours(thresh_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    print(f"DEBUG: Total contours found: {len(contours)}")
    
    entities = []
    id_counter = 0
    
    h_img, w_img = original_img.shape[:2]
    total_area = h_img * w_img
    min_area = 500  # Lowered min area
    
    # Regex to identify labels (percentages, numbers, lone symbols)
    # Matches: "55%", "30", "18.0", "%", "5,0"
    label_pattern = re.compile(r'^[\d\s\.,%]+$')

    for i, cnt in enumerate(contours):
        x, y, w, h = cv2.boundingRect(cnt)
        
        # Filter out huge container boxes (e.g. > 90% of image)
        if w * h > 0.9 * total_area:
            print(f"DEBUG: Ignoring contour {i} (too large: {w*h}/{total_area})")
            continue
            
        if w * h > 500: # Restored stricter min_area
            # Aspect ratio check
            aspect_ratio = float(w) / h
            # Relax aspect ratio to allow words (wide) and tall fragments
            if 0.2 < aspect_ratio < 20.0: # Restored stricter aspect ratio -> Relaxed to 20
                # Crop and OCR
                roi = original_img[y:y+h, x:x+w]
                
                # Preprocess ROI for OCR
                roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
                roi_thresh = cv2.threshold(roi_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
                
                # Configure tesseract for block of text
                custom_config = r'--oem 3 --psm 6' 
                text = pytesseract.image_to_string(roi, config=custom_config)
                # print(text)
                clean_text = text.strip()
                if clean_text:
                    if len(clean_text) < 2 and not clean_text.isalnum():
                         print(f"DEBUG: Rejected noise text: '{clean_text}' at {x},{y}")
                    else:
                        cx = x + w // 2
                        cy = y + h // 2
                        
                        # Determine type - defer to later classification
                        ent_type = "entity"
                        entities.append(Entity(id=id_counter, text=clean_text, rect=(x, y, w, h), center=(cx, cy), type=ent_type))
                        id_counter += 1
                else:
                     pass # print(f"DEBUG: Empty OCR for contour {i} at {x},{y}")
            else:
                print(f"DEBUG: Rejected aspect ratio {aspect_ratio:.2f} for contour {i} at {x},{y}")
        else:
             # print(f"DEBUG: Rejected small area {w*h} for contour {i}")
             pass
    
    # Filter out contained entities
    # Sort by area Descending (Largest First)
    entities.sort(key=lambda e: e.rect[2] * e.rect[3], reverse=True)
    
    # Filter out garbage artifacts that swallow real entities
    filtered_entities_list = []
    for e in entities:
        # Detect the specific large garbage blob
        area = e.rect[2] * e.rect[3]
        if area > 50000:
             print(f"DEBUG: Rejected huge garbage entity: Area {area} Text {e.text[:20]}...")
             continue
             
        if "es Ltd" in e.text and len(e.text) > 20:
             print(f"DEBUG: Rejected garbage entity: {e.text[:20]}...")
             continue
        filtered_entities_list.append(e)
    entities = filtered_entities_list
    
    unique_entities = []
    for e in entities:
        contained = False
        for other in unique_entities:
            if is_contained(e.rect, other.rect):
                contained = True
                break
        if not contained:
            unique_entities.append(e)
            
    # Re-sort top-to-bottom for hierarchy building
    unique_entities.sort(key=lambda e: e.rect[1])
    return unique_entities

def find_lines(thresh_img_for_text, original_img):
    # Use HSV Saturation to find yellow/orange lines
    hsv = cv2.cvtColor(original_img, cv2.COLOR_BGR2HSV)
    s_channel = hsv[:, :, 1]
    
    # Threshold saturation: Colorful things (lines) will be white, gray/white/black will be black
    _, line_mask = cv2.threshold(s_channel, 50, 255, cv2.THRESH_BINARY)
    
    # Also use Canny on the original image for black text lines or high contrast lines
    gray = cv2.cvtColor(original_img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    
    # Combine: Lines are either colorful OR edges
    combined = cv2.bitwise_or(line_mask, edges)
    
    # Dilate slightly to close gaps but avoid merging distinct lines
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    lines_img = cv2.dilate(combined, kernel, iterations=1)
    
    # Mask out borders
    h, w = lines_img.shape
    border = 15
    cv2.rectangle(lines_img, (0,0), (w, h), 0, border*2) 
    
    return lines_img

def merge_close_entities(entities):
    """
    Merge entities that are visually part of the same text block (fragmented).
    Phase 1: Horizontal Merge (lines).
    Phase 2: Vertical Merge (paragraphs).
    """
    if not entities: return []
    
    # Work with a list of Entity objects
    # We will iterate and merge in place or create new list
    
    # 1. Horizontal Merge
    entities.sort(key=lambda e: (e.center[1], e.rect[0]))
    merged_h = []
    
    if entities:
        curr = entities[0]
        for next_e in entities[1:]:
             # Check if close horizontally and roughly same Y
             dy = abs(curr.center[1] - next_e.center[1])
             dx = next_e.rect[0] - (curr.rect[0] + curr.rect[2])
             
             # Thresholds: roughly same line (dy < 15), close (dx < 20?)
             if dy < 15 and -10 < dx < 20:
                  # Merge
                  new_text = curr.text + " " + next_e.text
                  x = curr.rect[0]
                  y = min(curr.rect[1], next_e.rect[1])
                  w = (next_e.rect[0] + next_e.rect[2]) - x
                  h = max(curr.rect[1]+curr.rect[3], next_e.rect[1]+next_e.rect[3]) - y
                  curr = Entity(id=curr.id, text=new_text, rect=(x,y,w,h), center=(x+w//2, y+h//2))
             else:
                  merged_h.append(curr)
                  curr = next_e
        merged_h.append(curr)
        
    # 2. Vertical Merge
    merged_h.sort(key=lambda e: e.rect[1])
    merged_v = []
    
    if merged_h:
        curr = merged_h[0]
        for next_e in merged_h[1:]:
             # Check for stacking
             # Horizontal overlap
             x1 = max(curr.rect[0], next_e.rect[0])
             x2 = min(curr.rect[0]+curr.rect[2], next_e.rect[0]+next_e.rect[2])
             overlap = max(0, x2 - x1)
             
             # Vertical gap
             dy = next_e.rect[1] - (curr.rect[1] + curr.rect[3])
             
             min_w = min(curr.rect[2], next_e.rect[2])
             
             # Threshold: Significant overlap (> 50% of narrower box), Small gap (< 60px)
             if min_w > 0 and (overlap / min_w) > 0.5 and -10 < dy < 60:
                  # Merge with newline
                  new_text = curr.text + "\n" + next_e.text
                  x = min(curr.rect[0], next_e.rect[0])
                  y = curr.rect[1]
                  w = max(curr.rect[0]+curr.rect[2], next_e.rect[0]+next_e.rect[2]) - x
                  h = (next_e.rect[1] + next_e.rect[3]) - y
                  curr = Entity(id=curr.id, text=new_text, rect=(x,y,w,h), center=(x+w//2, y+h//2))
             else:
                  merged_v.append(curr)
                  curr = next_e
        merged_v.append(curr)
        
    return merged_v

def are_connected_visual(parent, child, lines_map, labels, all_entities):
    """
    Check if there is a visual path (lines) connecting parent to child.
    """
    # 1. Define ROI
    # Expand padding to catch lines that go slightly around
    pad = 40
    x_min = min(parent.rect[0], child.rect[0]) - pad
    x_max = max(parent.rect[0] + parent.rect[2], child.rect[0] + child.rect[2]) + pad
    y_min = min(parent.rect[1], child.rect[1]) - pad
    y_max = max(parent.rect[1] + parent.rect[3], child.rect[3] + child.rect[1]) + pad
    
    h_img, w_img = lines_map.shape[:2]
    x_min, x_max = max(0, x_min), min(w_img, x_max)
    y_min, y_max = max(0, y_min), min(h_img, y_max)
    
    roi_w = x_max - x_min
    roi_h = y_max - y_min
    
    if roi_w <= 0 or roi_h <= 0: return (False, [], [])

    # 2. Mask
    mask = lines_map[y_min:y_max, x_min:x_max].copy()
    
    # Block other entities
    blocking_pad = 10
    for e in all_entities:
        if e.id == parent.id or e.id == child.id: continue
        ex, ey, ew, eh = e.rect
        if not (ex > x_max or ex + ew < x_min or ey > y_max or ey + eh < y_min):
             cv2.rectangle(mask, 
                 (ex - x_min - blocking_pad, ey - y_min - blocking_pad), 
                 (ex + ew - x_min + blocking_pad, ey + eh - y_min + blocking_pad), 0, -1)

    # Start/End zones (parent/child) -> White
    cv2.rectangle(mask, (parent.rect[0]-x_min, parent.rect[1]-y_min), 
                  (parent.rect[0]+parent.rect[2]-x_min, parent.rect[1]+parent.rect[3]-y_min), 255, -1)
    cv2.rectangle(mask, (child.rect[0]-x_min, child.rect[1]-y_min), 
                  (child.rect[0]+child.rect[2]-x_min, child.rect[1]+child.rect[3]-y_min), 255, -1)

    # Floodfill from split point of parent (bottom center)
    start_x = (parent.rect[0] + parent.rect[2]//2) - x_min
    start_y = (parent.rect[1] + parent.rect[3]) - y_min
    start_x = max(0, min(roi_w-1, start_x))
    start_y = max(0, min(roi_h-1, start_y))
    
    # Improve start point finding if black (scan down)
    if mask[start_y, start_x] == 0:
         found = False
         for dy in range(20): # Look down 20px
              if start_y + dy < roi_h and mask[start_y+dy, start_x] != 0:
                   start_y += dy
                   found = True
                   break
         if not found:
              # Try scanning full width of parent bottom
              p_x1 = max(0, parent.rect[0]-x_min)
              p_x2 = min(roi_w, parent.rect[0]+parent.rect[2]-x_min)
              for px in range(p_x1, p_x2, 5):
                   if mask[start_y, px] != 0:
                        start_x = px
                        found = True
                        break

    if mask[start_y, start_x] == 0:
         return (False, [], [])

    flood_mask = np.zeros((roi_h + 2, roi_w + 2), np.uint8)
    try:
        if mask[start_y, start_x] > 0:
            cv2.floodFill(mask, flood_mask, (start_x, start_y), 128, flags=8 | (255 << 8))
        else:
            # Robust scan: 60px down + slight horizontal wiggle
            found_start = False
            for dy in range(60):
                yy = start_y + dy
                if yy >= roi_h: break
                for dx in range(-5, 6):
                    xx = start_x + dx
                    if 0 <= xx < roi_w and mask[yy, xx] > 0:
                         cv2.floodFill(mask, flood_mask, (xx, yy), 128, flags=8 | (255 << 8))
                         found_start = True
                         break
                if found_start: break
    except:
        return (False, [], [])
        
    # Create child masks for directionality check
    c_x1 = max(0, child.rect[0]-x_min)
    c_y1 = max(0, child.rect[1]-y_min)
    c_w = min(roi_w - c_x1, child.rect[2])
    c_h = min(roi_h - c_y1, child.rect[3])
    
    # Dilate the flooded path to bridge gap between Box Border and Text
    path_mask = (mask == 128).astype(np.uint8)
    kernel = np.ones((15, 15), np.uint8)
    dilated_path = cv2.dilate(path_mask, kernel, iterations=3)

    # Define Top Zone (Top 40% of child box + small buffer above)
    # We want the line to enter from the top.
    top_limit = c_h // 2
    child_top_roi = dilated_path[c_y1-5:c_y1+top_limit, c_x1:c_x1+c_w]
    
    # Check if path touches the top zone
    connected = False
    if child_top_roi.size > 0 and np.any(child_top_roi > 0):
         connected = True
    
    # If not connected via top, reject (even if connected via bottom/side-bottom)
    if not connected:
         # Double check if it's a "side" entry for a label? No, entities are boxes.
         # For imag1.png, text is inside box. Top of text is roughly top of entity.
         # For org_chart.png, entity is box. Line hits top of box.
         pass
    
    # Extract contours for debug visualization
    visual_path = []
    if connected:
        path_contours, _ = cv2.findContours(dilated_path, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # Offset contours back to original image coordinates
        for cnt in path_contours:
            cnt += np.array([x_min, y_min])
            visual_path.append(cnt)

    intersected_labels = []
    
    if connected:
         # Find labels on the path (mask == 128)
         path_mask = (mask == 128).astype(np.uint8) * 255
         dist_map = cv2.distanceTransform(cv2.bitwise_not(path_mask), cv2.DIST_L2, 5)
         
         for l in labels:
              l_cx = l.center[0] - x_min
              l_cy = l.center[1] - y_min
              if 0 <= l_cx < roi_w and 0 <= l_cy < roi_h:
                   dist = dist_map[l_cy, l_cx]
                   if dist < 50: # Label is near the path
                        intersected_labels.append((l, dist))
                        
    return (connected, intersected_labels, visual_path)

def classify_entities(entities):
    final_entities = []
    final_labels = []
    
    label_pattern = re.compile(r'^[=\d\s\.,%]+$')
    
    for e in entities:
        txt = e.text.strip()
        lower = txt.lower()
        
        # Heuristics
        is_label = False
        
        # 1. Regex for numbers/percentages
        if label_pattern.match(txt):
            is_label = True
        # 2. Keywords
        elif "control" in lower or "golden" in lower:
            is_label = True
        # 3. Short noisy text that isn't clearly a code (like 'UK')
        # If it's very short and Mixed Case or Lower Case, unlikely to be a Country Code
        elif len(txt) < 4:
            if not txt.isupper() and not txt.isdigit(): # "oS", "eT" -> Label/Noise
                is_label = True
        
        if is_label:
            e.type = "label"
            final_labels.append(e)
        else:
            e.type = "entity"
            final_entities.append(e)
            
    return final_entities, final_labels

def build_relationships_dag(entities, labels, lines_map):
    relationships = []
    # No merging
    merged_entities = entities 
    merged_entities.sort(key=lambda e: e.center[1])
    
    potential_links = []
    
    for child in merged_entities:
        for parent in merged_entities:
            if parent.id == child.id: continue
            
            # Parent must be higher (smaller Y)
            if parent.center[1] < child.center[1]:
                 # Filter out extreme horizontal jumps (cross-chart false positives)
                 dx = abs(parent.center[0] - child.center[0])
                 if dx > 400: continue

                 is_conn, candidates, visual_path = are_connected_visual(parent, child, lines_map, labels, merged_entities)
                 if is_conn:
                      print(f"  [Visual Match] {parent.text[:15]} -> {child.text[:15]}")
                      potential_links.append({
                          "parent": parent, "child": child, "candidates": candidates, "final_labels": [],
                          "debug_info": {"path_contours": visual_path}
                      })
                      
    # Assign labels
    all_claims = []
    for i, link in enumerate(potential_links):
        for lbl, dist in link["candidates"]:
            all_claims.append({"dist": dist, "label": lbl, "link_idx": i})
    all_claims.sort(key=lambda x: x["dist"])
    
    assigned = set()
    for c in all_claims:
        if c["label"].id not in assigned:
             potential_links[c["link_idx"]]["final_labels"].append(c["label"])
             assigned.add(c["label"].id)
             
    # Transitive Reduction: Remove direct A->C if A->B and B->C exist
    # 1. Build adjacency list
    adj = {e.id: set() for e in merged_entities}
    link_map = {} # (p_id, c_id) -> link_obj
    
    for link in potential_links:
        p_id = link["parent"].id
        c_id = link["child"].id
        adj[p_id].add(c_id)
        link_map[(p_id, c_id)] = link
        
    # 2. Check for transitive paths
    to_remove = set()
    for i in adj:
        for j in adj[i]:
            for k in adj[j]:
                if k in adj[i]:
                    # Found triangle i->j->k and i->k. Remove i->k
                    print(f"  [Transitive Reduction] Removing partial redundant link {link_map[(i,k)]['parent'].text[:10]} -> {link_map[(i,k)]['child'].text[:10]}")
                    to_remove.add((i, k))
                    
    # Filter potential_links
    final_links = []
    for link in potential_links:
        key = (link["parent"].id, link["child"].id)
        if key not in to_remove:
             final_links.append(link)
             
    # Output
    for link in final_links:
        pct = None
        for l in link["final_labels"]:
             nums = re.findall(r'\d+(?:\.\d+)?', l.text)
             if nums: pct = float(nums[0])
        
        relationships.append({
             "from": link["parent"].text.replace('\n', ' ').strip(),
             "to": link["child"].text.replace('\n', ' ').strip(),
             "type": "ownership",
             "percentage": pct
        })
        
    return relationships, merged_entities

def recover_relationships_by_labels(entities, labels, existing_relationships):
    """
    Heuristic Fallback: If visual path failed, check if a Percentage Label 
    sits perfectly between two entities.
    """
    # Create a set of existing links to avoid duplicates
    existing_links = set()
    for r in existing_relationships:
        existing_links.add((r["from"], r["to"]))
        
    recovered = []
    
    import re
    
    for l in labels:
        txt = l.text.strip().replace(',', '.')
        lower_txt = txt.lower()
        
        val = None
        rel_type = "ownership"
        extra = {}
        
        # Determine Label Type
        if "control" in lower_txt:
            rel_type = "control"
        elif "golden" in lower_txt:
            rel_type = "trust_beneficiary"
            extra["label"] = "Golden"
        # Heuristic for "approx 20%" etc
        elif re.search(r'\d', txt): 
             pass
        else:
             continue # Skip irrelevant labels
             
        # Find best parent/child pair for this label
        best_pair = None
        min_score = 100.0 # Strict distance threshold (pixels)
        
        for parent in entities:
             for child in entities:
                  if parent.id == child.id: continue
                  
                  # Calculate distance from Label Center to Line Segment (Parent-Child)
                  # Vector math
                  p = np.array(parent.center)
                  c = np.array(child.center)
                  l_pt = np.array(l.center)
                  
                  # Segment length squared
                  l2 = np.sum((p - c)**2)
                  if l2 == 0: continue
                  
                  # Projection
                  t = np.dot(l_pt - p, c - p) / l2
                  t = max(0, min(1, t))
                  projection = p + t * (c - p)
                  
                  dist = np.linalg.norm(l_pt - projection)
                  
                  # Line intersection check would be good here but expensive
                  # Stricter check: Distance must be very small (e.g. < 50) relative to image size
                  # Also enforce Parent and Child are not too far apart (e.g. < 400px), to avoid cross-chart links
                  dist_nodes = np.linalg.norm(p - c)
                  if 0.1 < t < 0.9 and dist < 50 and dist_nodes < 400:
                       best_pair = (parent, child)
                       min_score = dist
                       
        if best_pair:
             parent, child = best_pair
             p_name = parent.text.replace('\n', ' ').strip()
             c_name = child.text.replace('\n', ' ').strip()
             key = (p_name, c_name)
             
             if key not in existing_links:
                  print(f"  [Label Recovery] Found missing link via label '{l.text}': {p_name} -> {c_name}")
                  
                  new_rel = {
                      "from": p_name,
                      "to": c_name,
                      "type": rel_type
                  }
                  # Try extract number
                  try:
                      nums = re.findall(r'\d+(?:\.\d+)?', txt)
                      if nums:
                           new_rel["percentage"] = float(nums[0])
                  except: pass
                  
                  new_rel.update(extra)
                  
                  recovered.append(new_rel)
                  existing_links.add(key)
    
    return recovered
    


    return recovered

def main():
    image_path = 'image4.png'
    filename = os.path.basename(image_path)
    name, ext = os.path.splitext(filename)
    output_path = f'{name}_extracted.json'
    
    print(f"Processing {image_path}...")
    
    try:
        img, gray, thresh = preprocess_image(image_path)
        
        # 1. Find Entities (Boxes with Text)
        raw_items = find_text_boxes(thresh, img)
        
        # 2. Merge fragments
        merged_items = merge_close_entities(raw_items)
        
        # 3. Classify
        entities, labels = classify_entities(merged_items)
        
        print(f"Found {len(entities)} entities and {len(labels)} labels.")
        for e in entities:
             print(f" - ENTITY ID {e.id}: {e.text.replace(chr(10), ' ')} | Rect: {e.rect} | Center: {e.center}")
        for l in labels:
             print(f" - LABEL ID {l.id}: {l.text.replace(chr(10), ' ')} | Center: {l.center}")

        # 2. Build Hierarchy (DAG)
        # We need the lines map for visual validation
        lines_map = find_lines(thresh, img)
        relationships, entities = build_relationships_dag(entities, labels, lines_map)
        
        # 3. Recover missing relationships using orphaned percentage labels
        recovered_rels = recover_relationships_by_labels(entities, labels, relationships)
        relationships.extend(recovered_rels)
        
        # Build flat output structure
        # CRITICAL: Filter out 'debug_info' (contours) for JSON saving, but keep it for debug drawing
        clean_relationships = []
        for r in relationships:
             r_copy = r.copy()
             if "debug_info" in r_copy:
                 del r_copy["debug_info"]
             clean_relationships.append(r_copy)

        output_data = {
            "entities": [],
            "relationships": clean_relationships
        }
        
        # Populate entities with 1-based IDs
        entities_sorted = sorted(entities, key=lambda x: x.id)
        
        for idx, e in enumerate(entities_sorted):
            clean_name = e.text.replace('\n', ' ').strip()
            entity_id = f"E{idx + 1}"
            
            output_data["entities"].append({
                "id": entity_id,
                "name": clean_name
            })

        with open(output_path, 'w') as f:
            json.dump(output_data, f, indent=4)
        print(f"Successfully wrote hierarchy to {output_path}")
        
        # Debug: Draw boxes and relationships
        debug_img = img.copy()
        
        # We need a map to find node centers by name for drawing lines, 
        # since we only have names in 'relationships' now. 
        # (Naive lookup by exact string match)
        name_to_center = {e.text.replace('\n', ' ').strip(): e.center for e in entities}
        
        for e in entities:
            # Green for entities
            cv2.rectangle(debug_img, (e.rect[0], e.rect[1]), (e.rect[0]+e.rect[2], e.rect[1]+e.rect[3]), (0, 255, 0), 2)
            cv2.putText(debug_img, f"E{e.id}", (e.rect[0], e.rect[1]-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            
        for l in labels:
            # Red for labels
            cv2.rectangle(debug_img, (l.rect[0], l.rect[1]), (l.rect[0]+l.rect[2], l.rect[1]+l.rect[3]), (0, 0, 255), 2)
            cv2.putText(debug_img, l.text, (l.rect[0], l.rect[1]-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

        # Draw lines from relationships
        for rel in relationships:
            src_name = rel["from"]
            dst_name = rel["to"]
            
            # Check if we have curved path info
            if "debug_info" in rel and "path_contours" in rel["debug_info"]:
                 contours = rel["debug_info"]["path_contours"]
                 cv2.drawContours(debug_img, contours, -1, (0, 0, 255), 2)
            elif src_name in name_to_center and dst_name in name_to_center:
                 # Fallback to straight line (e.g. manual recovery)
                 start_pt = name_to_center[src_name]
                 end_pt = name_to_center[dst_name]
                 cv2.line(debug_img, start_pt, end_pt, (0, 0, 255), 2)
        
        debug_filename = f"debug_{image_path}"
        cv2.imwrite(debug_filename, debug_img)
        print(f"Saved debug visualization to {debug_filename}")
            
    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
