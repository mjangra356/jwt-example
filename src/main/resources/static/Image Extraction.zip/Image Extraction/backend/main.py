from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from services.ai_service import extract_relationships
from services.comparison_service import compare_results
import uvicorn
import shutil
import os
import json
import uuid
from typing import Optional

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Directory Setup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
FRONTEND_DIR = os.path.join(PROJECT_ROOT, "frontend")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# Mount uploads to serve images
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

@app.get("/")
async def read_index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

import hashlib

@app.post("/upload")
async def extract_entity_relationships(file: UploadFile = File(...)):
    try:
        # Read file content for hashing
        file_content = await file.read()
        file.seek(0) # Reset cursor if needed by other components (though we use content directly now)
        
        # Calculate Hash
        file_hash = hashlib.md5(file_content).hexdigest()
        file_extension = os.path.splitext(file.filename)[1]
        
        # Define cache paths
        cached_image_filename = f"cached_{file_hash}{file_extension}"
        cached_image_path = os.path.join(UPLOAD_DIR, cached_image_filename)
        
        cached_result_filename = f"cached_{file_hash}.json"
        cached_result_path = os.path.join(RESULTS_DIR, cached_result_filename)
        
        # Check Cache
        if os.path.exists(cached_image_path) and os.path.exists(cached_result_path):
            print(f"DEBUG: Cache hit for {file.filename} ({file_hash})")
            with open(cached_result_path, "r") as f:
                result = json.load(f)
            return {
                "original_image_url": f"/uploads/{cached_image_filename}",
                "json": result
            }

        # Cache Miss - Save and Process
        print(f"DEBUG: Cache miss for {file.filename} ({file_hash})")
        with open(cached_image_path, "wb") as f:
            f.write(file_content)
            
        # Extract data using AI Service
        try:
            # We already have bytes, pass them directly
            result = await extract_relationships(file_content)
                
            # Save extracted result to file
            with open(cached_result_path, "w") as f:
                json.dump(result, f, indent=2)

            # Construct response for frontend
            return {
                "original_image_url": f"/uploads/{cached_image_filename}",
                "json": result
            }
                
        except Exception as e:
            # If extraction fails, maybe delete the cached image so we retry next time?
            if os.path.exists(cached_image_path):
                os.remove(cached_image_path)
            raise e
            
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

from fastapi.exceptions import RequestValidationError
from fastapi.requests import Request
from fastapi.responses import JSONResponse

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    print(f"DEBUG: Validation Error: {exc}")
    # Return a more descriptive error response
    return JSONResponse(
        status_code=422,
        content={"detail": str(exc), "body": exc.body},
    )

@app.post("/compare")
async def compare_extracted_with_source(
    extracted_data: str = Form(...),
    ground_truth: UploadFile = File(...)
):
    try:
        extracted_json = json.loads(extracted_data)
        source_content = await ground_truth.read()
        source_json = json.loads(source_content)
        
        comparison = compare_results(extracted_json, source_json)
        return comparison
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
