import os
import base64
import json
import httpx
from dotenv import load_dotenv

load_dotenv()

AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")

async def extract_relationships(image_bytes: bytes) -> dict:
    encoded_image = base64.b64encode(image_bytes).decode('utf-8')
    
    headers = {
        "Content-Type": "application/json",
        "api-key": API_KEY,
    }
    
    system_prompt = """
    You are an expert data extractor. Your task is to analyze an image of an entity relationship diagram and extract the details into a strict JSON format.
    
    The diagram contains entities connected by lines or arrows, potentially with labels like ownership percentages.
    
    Output Format:
    {
        "Nodes": [
            { "ROOT_BVD_ID_NUMBER": "Entity ID", "ROOT_NAME": "Entity Name" }
        ],
        "Edges": [
            {
                "ParentBvDID": "Source Entity Name",
                "ChildBvDID": "Target Entity Name",
                "DirectPercentage": "Ownership percentage or label (e.g., '100%', 'Wholly Owned')"
            }
        ]
    }

    Note - "ROOT_BVD_ID_NUMBER": "Entity ID" , here Entity ID is the numeric ID of the entity in the diagram. , update it serially starting from 1.
    
    Rules:
    1. Extract ALL entities visible in the diagram.
    2. Extract ALL relationships indicated by lines/arrows.
    3. Be precise with names and numbers.
    4. Return ONLY valid JSON, no markdown formatting or explanation.
    """
    
    payload = {
        "messages": [
            {
                "role": "system", 
                "content": system_prompt
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Extract the entity relationships from this image."
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{encoded_image}"
                        }
                    }
                ]
            }
        ],
        "max_tokens": 4000,
        "temperature": 0.0,
        "response_format": { "type": "json_object" }
    }
    
    async with httpx.AsyncClient() as client:
        try:
            # Note: The endpoint key in .env might contain the full URL including query params
            # We need to handle that. Inspecting the provided .env value:
            # https://dev-openai-service-02.openai.azure.com/openai/deployments/novbatch1-cb0c8ab7-bfa0-42de-b6a8-80199fa2bd99/chat/completions?api-version=2025-01-01-preview.azure.com/
            # It seems to be the full URL for chat completions.
            
            response = await client.post(AZURE_ENDPOINT, headers=headers, json=payload, timeout=60.0)
            response.raise_for_status()
            
            result = response.json()
            content = result['choices'][0]['message']['content']
            data = json.loads(content)
            if "Summary" not in data:
                data["Summary"] = {}
            data["Summary"]["Total_Nodes"] = len(data.get("Nodes", []))
            data["Summary"]["Total_Edges"] = len(data.get("Edges", []))
            return data
            
        except httpx.HTTPError as e:
            error_msg = f"HTTP Error: {e}\n"
            if hasattr(e, 'response'):
                 error_msg += f"Response: {e.response.text}\n"
            print(error_msg)
            with open("error_log.txt", "a") as f:
                f.write(error_msg + "\n")
            raise Exception(f"Failed to call Azure OpenAI: {str(e)}")
        except Exception as e:
             print(f"Error: {e}")
             with open("error_log.txt", "a") as f:
                f.write(f"General Error: {str(e)}\n")
             raise Exception(f"Error processing image: {str(e)}")
