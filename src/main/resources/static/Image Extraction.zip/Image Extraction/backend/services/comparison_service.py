def compare_results(extracted_json: dict, source_json: dict) -> dict:
    """
    Compares the extracted JSON with the source JSON.
    Returns a dictionary containing differences.
    """
    comparison = {
        "counts": {
            "source_entities": len(source_json.get('Nodes', [])),
            "extracted_entities": len(extracted_json.get('Nodes', [])),
            "source_relationships": len(source_json.get('Edges', [])),
            "extracted_relationships": len(extracted_json.get('Edges', []))
        },
        "Nodes": {
            "missing": [],  # In source, not in extracted
            "extra": [],    # In extracted, not in source
            "matched": []   # In both
        },
        "Edges": {
            "missing": [],
            "extra": [],
            "mismatched_ownership": [],
            "matched": []
        }
    }

    # compare entities
    source_entities = {e.get('ROOT_NAME'): e for e in source_json.get('Nodes', [])}
    extracted_entities = {e.get('ROOT_NAME'): e for e in extracted_json.get('Nodes', [])}

    for name, entity in source_entities.items():
        if name not in extracted_entities:
            comparison["Nodes"]["missing"].append(entity)
        else:
             comparison["Nodes"]["matched"].append(entity)

    for name, entity in extracted_entities.items():
        if name not in source_entities:
            comparison["Nodes"]["extra"].append(entity)

    # compare relationships
    # Key usage: (from, to)
    # Helper to normalize keys (strip whitespace)
    def get_rel_key(r):
        return (str(r.get('ParentBvDID', '')).strip(), str(r.get('ChildBvDID', '')).strip())

    source_rels = {}
    for r in source_json.get('Edges', []):
        key = get_rel_key(r)
        source_rels[key] = r

    extracted_rels = {}
    for r in extracted_json.get('Edges', []):
        key = get_rel_key(r)
        extracted_rels[key] = r

    for key, rel in source_rels.items():
        if key not in extracted_rels:
            comparison["Edges"]["missing"].append(rel)
        else:
            # Check ownership mismatch (mapped to percentage)
            ext_rel = extracted_rels[key]
            # Normalize values for comparison
            # Handle both 'percentage' and 'ownership' keys as flexible inputs
            p_src = str(rel.get('DirectPercentage', rel.get('ownership', ''))).replace('%','').strip()
            p_ext = str(ext_rel.get('DirectPercentage', ext_rel.get('ownership', ''))).replace('%','').strip()
            
            # Check for "None" or "null" strings
            if p_src in ['None', 'null', 'None.0']: p_src = ""
            if p_ext in ['None', 'null', 'None.0']: p_ext = ""

            if p_src != p_ext:
                 comparison["Edges"]["mismatched_ownership"].append({
                     "ParentBvDID": key[0],
                     "ChildBvDID": key[1],
                     "source_ownership": rel.get('DirectPercentage') or rel.get('ownership'),
                     "extracted_ownership": ext_rel.get('DirectPercentage') or ext_rel.get('ownership')
                 })
            else:
                comparison["Edges"]["matched"].append(rel)

    for key, rel in extracted_rels.items():
        if key not in source_rels:
            comparison["Edges"]["extra"].append(rel)

    return comparison
